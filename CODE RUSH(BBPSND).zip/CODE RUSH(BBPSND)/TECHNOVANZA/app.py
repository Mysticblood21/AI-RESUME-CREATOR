from flask import Flask, request, jsonify, send_file, send_from_directory
import requests
import os
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, Image as RLImage
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.pdfgen import canvas
import io
from dotenv import load_dotenv
import base64
from PIL import Image

load_dotenv()

app = Flask(__name__)

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent"

def query_ai(prompt):
    if not GEMINI_API_KEY or GEMINI_API_KEY == "":
        return "⚠️ NO GEMINI API KEY FOUND"
    
    try:
        url = f"{GEMINI_API_URL}?key={GEMINI_API_KEY}"
        
        payload = {
            "contents": [{
                "parts": [{"text": prompt}]
            }],
            "generationConfig": {
                "temperature": 0.7,
                "topK": 40,
                "topP": 0.95,
                "maxOutputTokens": 2048,
            }
        }
        
        headers = {"Content-Type": "application/json"}
        response = requests.post(url, json=payload, headers=headers, timeout=30)
        
        if response.status_code != 200:
            return f"⚠️ API ERROR: {response.status_code}"
        
        result = response.json()
        
        if 'candidates' in result and len(result['candidates']) > 0:
            candidate = result['candidates'][0]
            if 'content' in candidate and 'parts' in candidate['content']:
                parts = candidate['content']['parts']
                if len(parts) > 0 and 'text' in parts[0]:
                    return parts[0]['text']
        
        return "⚠️ Unexpected response format"
        
    except Exception as e:
        return f"⚠️ Error: {str(e)}"

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/style.css')
def style():
    try:
        return send_from_directory('.', 'styles.css')
    except:
        return send_from_directory('.', 'style.css')

@app.route('/script.js')
def script():
    return send_from_directory('.', 'script.js')

@app.route('/analyze', methods=['POST'])
def analyze():
    try:
        data = request.json
        
        personal_info = data.get('personalInfo', {})
        education = data.get('education', [])
        current_job = data.get('currentJob', {})
        desired_job = data.get('desiredJob', {})
        skills = data.get('skills', [])
        experiences = data.get('experiences', [])
        
        # Build sections only if data exists
        edu_text = ""
        if education:
            edu_text = "\n".join([f"- {edu.get('degree')} from {edu.get('institution')} ({edu.get('year')})" for edu in education])
        
        skills_text = ""
        if skills:
            skills_text = ", ".join(skills)
        
        experiences_text = ""
        if experiences:
            exp_lines = []
            for exp in experiences:
                exp_line = f"\n{exp.get('title', 'Position')}"
                if exp.get('company'):
                    exp_line += f" at {exp.get('company')}"
                if exp.get('duration'):
                    exp_line += f" ({exp.get('duration')})"
                if exp.get('technologies'):
                    exp_line += f"\nTechnologies: {exp.get('technologies')}"
                if exp.get('description'):
                    exp_line += f"\n{exp.get('description')}"
                exp_lines.append(exp_line)
            experiences_text = "\n".join(exp_lines)
        
        current_job_text = ""
        if current_job.get('title') or current_job.get('company'):
            current_job_text = f"""Current Position: {current_job.get('title', 'N/A')} at {current_job.get('company', 'N/A')}
Current Job Description: {current_job.get('description', 'None provided')}"""
        else:
            current_job_text = "Current Position: Not provided"
        
        prompt = f"""You are an expert career advisor and resume writer. Analyze this resume and provide detailed, actionable career advice.

RESUME INFORMATION:
Name: {personal_info.get('name')}
Location: {personal_info.get('location', 'Not provided')}

Education:
{edu_text if edu_text else 'Not provided'}

Current Skills: {skills_text if skills_text else 'Not provided'}

Experience & Projects:
{experiences_text if experiences_text else 'Not provided'}

{current_job_text}

Career Goals:
- Target Role: {desired_job.get('targetRole')}
- Target Industry: {desired_job.get('targetIndustry')}

IMPORTANT INSTRUCTIONS:
- Do NOT assume or make up information about skills, experience, or employment status
- Do NOT assume the user is currently employed if no current job details were provided
- Only analyze and provide advice based on information explicitly provided
- If information is missing, explicitly note it as "Not provided" in your analysis
- Focus your recommendations on the specific data given

PROVIDE A DETAILED ANALYSIS WITH:

1. KEY SKILL GAPS
List 5-7 specific technical and soft skills needed for the target role based on what's provided.

2. RESUME ISSUES
Identify problems in job descriptions and presentation (if current job is provided).

3. EXPERIENCE ANALYSIS
Evaluate the projects and experience provided. Suggest improvements for descriptions and how to better highlight achievements with quantifiable metrics.

4. RECOMMENDATIONS
Provide actionable advice to improve the resume based on available information.

5. CERTIFICATIONS & LEARNING PATHS
Suggest relevant certifications and courses for the target role.

6. ACTION PLAN
Create a detailed 3-month action plan.

Be specific, professional, and actionable. Do not assume employment history."""

        ai_response = query_ai(prompt)
        
        return jsonify({
            'success': True,
            'analysis': ai_response
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/improve-resume', methods=['POST'])
def improve_resume():
    try:
        data = request.json
        
        personal_info = data.get('personalInfo', {})
        education = data.get('education', [])
        current_job = data.get('currentJob', {})
        desired_job = data.get('desiredJob', {})
        skills = data.get('skills', [])
        experiences = data.get('experiences', [])
        
        # Build sections only if data exists
        edu_text = ""
        if education:
            edu_text = "\n".join([f"- {edu.get('degree')} from {edu.get('institution')} ({edu.get('year')})" for edu in education])
        
        skills_text = ""
        if skills:
            skills_text = ", ".join(skills)
        
        experiences_text = ""
        if experiences:
            exp_lines = []
            for exp in experiences:
                exp_line = f"- {exp.get('title', 'Position')}"
                if exp.get('company'):
                    exp_line += f" at {exp.get('company')}"
                if exp.get('technologies'):
                    exp_line += f" | Tech: {exp.get('technologies')}"
                exp_lines.append(exp_line)
            experiences_text = "\n".join(exp_lines)
        
        experience_section = ""
        if experiences:
            experience_json = []
            for exp in experiences:
                experience_json.append(f'''    {{
      "title": "{exp.get('title', 'Improved Title')}",
      "company": "{exp.get('company', 'Company Name')}",
      "duration": "{exp.get('duration', 'Duration')}",
      "technologies": "{exp.get('technologies', 'Technologies')}",
      "description": "• Achievement 1 with quantifiable results\\n• Achievement 2 with impact metrics\\n• Achievement 3 showing leadership\\n• Achievement 4 demonstrating technical skills"
    }}''')
            experience_section = ",\n".join(experience_json)
        elif current_job.get('title') or current_job.get('company'):
            experience_section = f'''    {{
      "title": "{current_job.get('title', 'Improved Title')}",
      "company": "{current_job.get('company', 'Company Name')}",
      "duration": "Current",
      "technologies": "",
      "description": "• Achievement 1 with quantifiable results\\n• Achievement 2 with impact metrics\\n• Achievement 3 showing leadership\\n• Achievement 4 demonstrating technical skills"
    }}'''
        else:
            experience_section = ""
        
        prompt = f"""You are an expert resume writer. Improve this resume for the target role. Return ONLY valid JSON with this exact structure:

{{
  "personalInfo": {{
    "name": "{personal_info.get('name')}",
    "email": "{personal_info.get('email')}",
    "phone": "{personal_info.get('phone')}",
    "location": "{personal_info.get('location')}"
  }},
  "careerObjective": "Write a powerful 2-3 sentence career objective for {desired_job.get('targetRole')} role",
  "skills": ["skill1", "skill2", "skill3", "skill4", "skill5", "skill6"],
  "experience": [{experience_section}],
  "education": {education}
}}

Current Skills: {skills_text if skills_text else 'Not provided'}
Current Experience: {experiences_text if experiences_text else 'Not provided'}
Target Role: {desired_job.get('targetRole')}
Target Industry: {desired_job.get('targetIndustry')}

IMPORTANT:
- Do NOT assume employment history if current job is empty
- Only include experience section if job/project details were provided
- If no current job or experience was provided, return empty array for experience: "experience": []
- Make recommendations based only on provided information
- Make it ATS-friendly, use strong action verbs, add metrics where possible
- Return ONLY the JSON, no other text."""

        ai_response = query_ai(prompt)
        
        import json
        try:
            # Clean the response
            clean_response = ai_response.strip()
            if clean_response.startswith('```json'):
                clean_response = clean_response[7:]
            if clean_response.startswith('```'):
                clean_response = clean_response[3:]
            if clean_response.endswith('```'):
                clean_response = clean_response[:-3]
            clean_response = clean_response.strip()
            
            improved_data = json.loads(clean_response)
            return jsonify({
                'success': True,
                'improved': improved_data
            })
        except Exception as parse_error:
            return jsonify({
                'success': False,
                'error': f'AI response was not valid JSON: {str(parse_error)}'
            }), 500
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/generate-pdf', methods=['POST'])
def generate_pdf():
    try:
        data = request.json
        buffer = io.BytesIO()
        
        # Create document with better margins
        doc = SimpleDocTemplate(
            buffer, 
            pagesize=letter,
            topMargin=0.5*inch, 
            bottomMargin=0.5*inch,
            leftMargin=0.75*inch, 
            rightMargin=0.75*inch
        )
        
        styles = getSampleStyleSheet()
        
        # Enhanced styles
        name_style = ParagraphStyle(
            'NameStyle',
            parent=styles['Heading1'],
            fontSize=28,
            textColor=colors.HexColor('#1a365d'),
            spaceAfter=4,
            alignment=TA_LEFT,
            fontName='Helvetica-Bold',
            leading=32
        )
        
        contact_style = ParagraphStyle(
            'ContactStyle',
            parent=styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#4a5568'),
            alignment=TA_LEFT,
            spaceAfter=12,
            fontName='Helvetica'
        )
        
        section_title_style = ParagraphStyle(
            'SectionTitle',
            parent=styles['Heading2'],
            fontSize=12,
            textColor=colors.HexColor('#2d3748'),
            spaceAfter=8,
            spaceBefore=12,
            fontName='Helvetica-Bold',
            borderPadding=(0, 0, 3, 0),
            borderColor=colors.HexColor('#4299e1'),
            borderWidth=2,
            leftIndent=0
        )
        
        job_title_style = ParagraphStyle(
            'JobTitle',
            parent=styles['Normal'],
            fontSize=11,
            textColor=colors.HexColor('#2d3748'),
            fontName='Helvetica-Bold',
            spaceAfter=2
        )
        
        company_style = ParagraphStyle(
            'CompanyStyle',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#4a5568'),
            fontName='Helvetica-Oblique',
            spaceAfter=6
        )
        
        body_style = ParagraphStyle(
            'BodyStyle',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#2d3748'),
            leading=14,
            spaceAfter=8,
            alignment=TA_JUSTIFY,
            fontName='Helvetica'
        )
        
        bullet_style = ParagraphStyle(
            'BulletStyle',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#2d3748'),
            leading=13,
            leftIndent=20,
            bulletIndent=10,
            spaceAfter=4,
            fontName='Helvetica',
            bulletFontName='Symbol'
        )
        
        content = []
        personal = data.get('personalInfo', {})
        photo_data = data.get('photo')
        
        # Header section with photo
        header_data = []
        
        # Process photo if provided
        photo_img = None
        if photo_data and photo_data.startswith('data:image'):
            try:
                # Extract base64 data
                photo_base64 = photo_data.split(',')[1]
                photo_bytes = base64.b64decode(photo_base64)
                
                # Create PIL Image
                photo_pil = Image.open(io.BytesIO(photo_bytes))
                
                # Resize to passport size (maintaining aspect ratio)
                target_width = 1.2 * inch
                target_height = 1.5 * inch
                photo_pil.thumbnail((int(target_width * 2), int(target_height * 2)), Image.Resampling.LANCZOS)
                
                # Save to bytes
                photo_buffer = io.BytesIO()
                photo_pil.save(photo_buffer, format='PNG')
                photo_buffer.seek(0)
                
                # Create ReportLab Image
                photo_img = RLImage(photo_buffer, width=target_width, height=target_height)
            except Exception as e:
                print(f"Error processing photo: {e}")
        
        if photo_img:
            # Create table with photo and name/contact info
            name_contact_cell = []
            name_contact_cell.append(Paragraph(personal.get('name', 'YOUR NAME').upper(), name_style))
            
            contact_parts = []
            if personal.get('email'):
                contact_parts.append(personal.get('email'))
            if personal.get('phone'):
                contact_parts.append(personal.get('phone'))
            if personal.get('location'):
                contact_parts.append(personal.get('location'))
            
            contact_info = " • ".join(contact_parts)
            name_contact_cell.append(Paragraph(contact_info, contact_style))
            
            header_table = Table(
                [[name_contact_cell, photo_img]],
                colWidths=[5.3*inch, 1.5*inch]
            )
            header_table.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('ALIGN', (1, 0), (1, 0), 'RIGHT'),
            ]))
            content.append(header_table)
        else:
            # No photo - just name and contact
            content.append(Paragraph(personal.get('name', 'YOUR NAME').upper(), name_style))
            
            contact_parts = []
            if personal.get('email'):
                contact_parts.append(personal.get('email'))
            if personal.get('phone'):
                contact_parts.append(personal.get('phone'))
            if personal.get('location'):
                contact_parts.append(personal.get('location'))
            
            contact_info = " • ".join(contact_parts)
            content.append(Paragraph(contact_info, contact_style))
        
        content.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#4299e1'), 
                                 spaceAfter=12, spaceBefore=6))
        
        # Career Objective
        career_obj = data.get('careerObjective', '')
        if career_obj:
            content.append(Paragraph("PROFESSIONAL SUMMARY", section_title_style))
            content.append(Spacer(1, 0.05*inch))
            content.append(Paragraph(career_obj, body_style))
        
        # Skills
        skills_list = data.get('skills', [])
        improved_skills = data.get('improvedSkills', [])
        
        display_skills = improved_skills if improved_skills else skills_list
        
        if display_skills:
            content.append(Paragraph("CORE COMPETENCIES", section_title_style))
            content.append(Spacer(1, 0.05*inch))
            
            # Create a more professional skills layout
            skills_rows = []
            for i in range(0, len(display_skills), 3):
                row = display_skills[i:i+3]
                skills_rows.append(row)
            
            if skills_rows:
                skills_table = Table(skills_rows, colWidths=[2.2*inch, 2.2*inch, 2.2*inch])
                skills_table.setStyle(TableStyle([
                    ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 0), (-1, -1), 9),
                    ('TEXTCOLOR', (0, 0), (-1, -1), colors.HexColor('#2d3748')),
                    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                    ('LEFTPADDING', (0, 0), (-1, -1), 0),
                    ('RIGHTPADDING', (0, 0), (-1, -1), 10),
                    ('TOPPADDING', (0, 0), (-1, -1), 3),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
                ]))
                content.append(skills_table)
                content.append(Spacer(1, 0.1*inch))
        
        # Experience
        experience_list = data.get('experience', [])
        experiences_list = data.get('experiences', [])
        current = data.get('currentJob', {})
        
        # Combine all experience sources (prioritize AI-improved over original)
        all_experiences = []
        
        # If we have AI-improved experience, use that instead of original experiences
        if experience_list:
            all_experiences.extend(experience_list)
        elif experiences_list:
            # Only use original experiences if no AI-improved version exists
            all_experiences.extend(experiences_list)
        
        # Add current job only if it's not already in the experience list
        if current.get('title') or current.get('company'):
            # Check if current job is not already included
            current_title = current.get('title', '').strip().lower()
            is_duplicate = False
            
            for exp in all_experiences:
                exp_title = exp.get('title', '').strip().lower()
                if current_title and exp_title and current_title == exp_title:
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                all_experiences.append({
                    'title': current.get('title', ''),
                    'company': current.get('company', ''),
                    'duration': 'Current',
                    'technologies': '',
                    'description': current.get('description', '')
                })
        
        # Only show experience section if there's actual data
        if all_experiences:
            content.append(Paragraph("PROFESSIONAL EXPERIENCE & PROJECTS", section_title_style))
            content.append(Spacer(1, 0.05*inch))
            
            for exp in all_experiences:
                if exp.get('title'):
                    content.append(Paragraph(exp.get('title', ''), job_title_style))
                
                company_duration = []
                if exp.get('company'):
                    company_duration.append(exp.get('company'))
                if exp.get('duration'):
                    company_duration.append(exp.get('duration'))
                
                if company_duration:
                    company_text = " • ".join(company_duration)
                    content.append(Paragraph(company_text, company_style))
                
                if exp.get('technologies'):
                    tech_text = f"<b>Technologies:</b> {exp.get('technologies')}"
                    content.append(Paragraph(tech_text, body_style))
                
                if exp.get('description'):
                    desc = exp.get('description', '')
                    lines = desc.split('\n')
                    for line in lines:
                        line = line.strip()
                        if line:
                            if line.startswith('•'):
                                line = line[1:].strip()
                            content.append(Paragraph(f"• {line}", bullet_style))
                
                content.append(Spacer(1, 0.12*inch))
        
        # Education
        education_list = data.get('education', [])
        if education_list:
            content.append(Paragraph("EDUCATION", section_title_style))
            content.append(Spacer(1, 0.05*inch))
            
            for edu in education_list:
                degree_text = f"<b>{edu.get('degree', '')}</b>"
                content.append(Paragraph(degree_text, job_title_style))
                
                institution_text = f"{edu.get('institution', '')} • Graduated: {edu.get('year', '')}"
                content.append(Paragraph(institution_text, company_style))
                content.append(Spacer(1, 0.08*inch))
        
        doc.build(content)
        buffer.seek(0)
        
        return send_file(
            buffer,
            mimetype='application/pdf',
            as_attachment=True,
            download_name='professional_resume.pdf'
        )
    
    except Exception as e:
        print(f"PDF Generation Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("\n" + "="*60)
    print("🚀 AI Resume Builder Starting...")
    print("="*60)
    
    if GEMINI_API_KEY and GEMINI_API_KEY != "":
        print("✅ Google Gemini API Key: Found")
    else:
        print("⚠️  Google Gemini API Key: NOT FOUND")
    
    print("\n📱 Open in browser: http://localhost:5000")
    print("="*60 + "\n")
    
    app.run(debug=True, port=5000)