let educationCount = 1;
let experienceCount = 1;
let skills = [];
let photoDataUrl = null;

// Skills management
document.getElementById('skillInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        const skillInput = e.target;
        const skill = skillInput.value.trim();
        
        if (skill && !skills.includes(skill)) {
            skills.push(skill);
            addSkillTag(skill);
            skillInput.value = '';
        }
    }
});

function addSkillTag(skill) {
    const container = document.getElementById('skillsContainer');
    const tag = document.createElement('div');
    tag.className = 'skill-tag';
    tag.innerHTML = `
        <span>${skill}</span>
        <button type="button" onclick="removeSkill('${skill.replace(/'/g, "\\'")}')">×</button>
    `;
    container.appendChild(tag);
}

function removeSkill(skill) {
    skills = skills.filter(s => s !== skill);
    updateSkillsDisplay();
}

function updateSkillsDisplay() {
    const container = document.getElementById('skillsContainer');
    container.innerHTML = '';
    skills.forEach(skill => addSkillTag(skill));
}

// Photo upload handling
document.getElementById('photoInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        if (file.size > 2 * 1024 * 1024) {
            alert('Photo size should be less than 2MB');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(event) {
            photoDataUrl = event.target.result;
            const preview = document.getElementById('photoPreview');
            preview.innerHTML = `
                <img src="${photoDataUrl}" alt="Profile Photo">
                <button type="button" onclick="removePhoto()" class="remove-photo">×</button>
            `;
        };
        reader.readAsDataURL(file);
    }
});

function removePhoto() {
    photoDataUrl = null;
    document.getElementById('photoPreview').innerHTML = '';
    document.getElementById('photoInput').value = '';
}

function addEducation() {
    educationCount++;
    const container = document.getElementById('educationContainer');
    const newEntry = document.createElement('div');
    newEntry.className = 'education-entry';
    newEntry.innerHTML = `
        <div class="form-group">
            <label>Degree *</label>
            <input type="text" class="edu-degree" required>
        </div>
        <div class="form-group">
            <label>Institution *</label>
            <input type="text" class="edu-institution" required>
        </div>
        <div class="form-group">
            <label>Year *</label>
            <input type="text" class="edu-year" required>
        </div>
        <button type="button" class="btn-remove-education" onclick="removeEducation(this)">✕ Remove Education</button>
    `;
    container.appendChild(newEntry);
}

function removeEducation(button) {
    button.closest('.education-entry').remove();
}

function addExperience() {
    experienceCount++;
    const container = document.getElementById('experienceContainer');
    const newEntry = document.createElement('div');
    newEntry.className = 'experience-entry';
    newEntry.innerHTML = `
        <div class="form-group">
            <label>Title/Project Name *</label>
            <input type="text" class="exp-title" placeholder="e.g., Software Developer Intern or AI Chatbot Project">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Company/Organization</label>
                <input type="text" class="exp-company" placeholder="Company name or 'Personal Project'">
            </div>
            <div class="form-group">
                <label>Duration</label>
                <input type="text" class="exp-duration" placeholder="e.g., Jan 2023 - Present">
            </div>
        </div>
        <div class="form-group">
            <label>Technologies Used</label>
            <input type="text" class="exp-technologies" placeholder="e.g., Python, TensorFlow, AWS, Docker">
        </div>
        <div class="form-group">
            <label>Description & Achievements</label>
            <textarea class="exp-description" rows="4" placeholder="• Describe your role and responsibilities&#10;• Add quantifiable achievements (e.g., improved performance by 30%)&#10;• Highlight key contributions and impact"></textarea>
        </div>
        <button type="button" class="btn-remove-experience" onclick="removeExperience(this)">✕ Remove Experience</button>
    `;
    container.appendChild(newEntry);
}

function removeExperience(button) {
    button.closest('.experience-entry').remove();
}

function collectFormData() {
    const education = [];
    const educationEntries = document.querySelectorAll('.education-entry');
    
    educationEntries.forEach(entry => {
        const degree = entry.querySelector('.edu-degree').value;
        const institution = entry.querySelector('.edu-institution').value;
        const year = entry.querySelector('.edu-year').value;
        
        if (degree && institution && year) {
            education.push({ degree, institution, year });
        }
    });
    
    const experiences = [];
    const experienceEntries = document.querySelectorAll('.experience-entry');
    
    experienceEntries.forEach(entry => {
        const title = entry.querySelector('.exp-title').value;
        const company = entry.querySelector('.exp-company').value;
        const duration = entry.querySelector('.exp-duration').value;
        const technologies = entry.querySelector('.exp-technologies').value;
        const description = entry.querySelector('.exp-description').value;
        
        if (title || description) {
            experiences.push({ 
                title, 
                company, 
                duration,
                technologies,
                description 
            });
        }
    });
    
    return {
        personalInfo: {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            location: document.getElementById('location').value
        },
        education: education,
        skills: skills,
        experiences: experiences,
        currentJob: {
            title: document.getElementById('currentTitle').value,
            company: document.getElementById('currentCompany').value,
            description: document.getElementById('currentDescription').value
        },
        desiredJob: {
            targetRole: document.getElementById('targetRole').value,
            targetIndustry: document.getElementById('targetIndustry').value
        },
        photo: photoDataUrl
    };
}

document.getElementById('resumeForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const analysisSection = document.getElementById('analysisSection');
    const analysisContent = document.getElementById('analysisContent');
    
    analysisSection.style.display = 'block';
    analysisContent.innerHTML = '<div class="loading">Analyzing your resume with AI</div>';
    analysisSection.scrollIntoView({ behavior: 'smooth' });
    
    const formData = collectFormData();
    
    try {
        const response = await fetch('/analyze', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            analysisContent.innerHTML = `<pre style="white-space: pre-wrap; font-family: inherit;">${result.analysis}</pre>`;
        } else {
            analysisContent.innerHTML = `<p style="color: #ff6b6b;">Error: ${result.error}</p>`;
        }
    } catch (error) {
        analysisContent.innerHTML = `<p style="color: #ff6b6b;">Error connecting to server: ${error.message}</p>`;
    }
});

async function generatePDF(useImproved = false) {
    const formData = collectFormData();
    
    if (useImproved) {
        // Show loading
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'loading';
        loadingDiv.textContent = 'Generating AI-improved resume';
        loadingDiv.style.position = 'fixed';
        loadingDiv.style.top = '50%';
        loadingDiv.style.left = '50%';
        loadingDiv.style.transform = 'translate(-50%, -50%)';
        loadingDiv.style.background = 'rgba(0, 0, 0, 0.8)';
        loadingDiv.style.padding = '30px 50px';
        loadingDiv.style.borderRadius = '15px';
        loadingDiv.style.zIndex = '10000';
        document.body.appendChild(loadingDiv);
        
        try {
            // First, get improved resume data from AI
            const improveResponse = await fetch('/improve-resume', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            
            const improveResult = await improveResponse.json();
            
            if (improveResult.success) {
                // Merge improved data with original data
                const improvedData = {
                    ...formData,
                    careerObjective: improveResult.improved.careerObjective,
                    improvedSkills: improveResult.improved.skills,
                    experience: improveResult.improved.experience,
                    education: improveResult.improved.education || formData.education
                };
                
                // Generate PDF with improved data
                const pdfResponse = await fetch('/generate-pdf', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(improvedData)
                });
                
                if (pdfResponse.ok) {
                    const blob = await pdfResponse.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'ai_improved_resume.pdf';
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    document.body.removeChild(a);
                } else {
                    alert('Error generating PDF');
                }
            } else {
                alert('Error improving resume: ' + improveResult.error);
            }
        } catch (error) {
            alert('Error: ' + error.message);
        } finally {
            document.body.removeChild(loadingDiv);
        }
    } else {
        // Generate regular PDF
        try {
            const response = await fetch('/generate-pdf', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'resume.pdf';
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            } else {
                alert('Error generating PDF');
            }
        } catch (error) {
            alert('Error: ' + error.message);
        }
    }
}

function improveAndGeneratePDF() {
    generatePDF(true);
}