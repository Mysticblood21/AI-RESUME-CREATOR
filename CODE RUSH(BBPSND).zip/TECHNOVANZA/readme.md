# AI Resume Builder

1. Install dependencies
```bash
pip install flask requests reportlab python-dotenv pillow
```

2. Create `.env` file
```bash
GEMINI_API_KEY=your_api_key_here(ALREADY DONE)
```

## Run Locally

```bash
python app.py
```

Open: http://localhost:5000

## Run online with ngrok

1. Configure ngrok
```bash
ngrok config add-authtoken YOUR_AUTHTOKEN(ALREADY DONE)
```

3. Start Flask
```bash
python app.py
```

4. Start ngrok
```bash
ngrok http 5000
```