let currentStep = 1;
const totalSteps = 6;
let resumeData = {
    personalInfo: {},
    experience: [],
    skills: [],
    education: [],
    summary: '',
    targetRole: '',
    industry: '',
    photo: null
};

const progressFill = document.getElementById('progress-fill');
const steps = document.querySelectorAll('.step');
const formSteps = document.querySelectorAll('.form-step');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const loadingOverlay = document.getElementById('loading-overlay');
const toastContainer = document.getElementById('toast-container');

document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
    updateProgress();
});

function initializeEventListeners() {
    nextBtn.addEventListener('click', nextStep);
    prevBtn.addEventListener('click', prevStep);
    
    document.getElementById('generate-summary').addEventListener('click', generateAISummary);
    document.getElementById('get-suggestions').addEventListener('click', getAISuggestions);
    document.getElementById('improve-description').addEventListener('click', improveJobDescription);
    document.getElementById('recommend-skills').addEventListener('click', recommendSkills);
    
    document.getElementById('add-experience').addEventListener('click', addExperience);
    document.getElementById('add-education').addEventListener('click', addEducation);
    document.getElementById('skill-input').addEventListener('keypress', handleSkillInput);
    
    document.getElementById('download-btn').addEventListener('click', downloadResume);
    document.getElementById('save-resume').addEventListener('click', saveResume);
    
    document.getElementById('currentJob').addEventListener('change', handleCurrentJob);
    
    document.getElementById('photo').addEventListener('change', handlePhotoUpload);
}

function nextStep() {
    if (validateCurrentStep()) {
        if (currentStep < totalSteps) {
            currentStep++;
            updateStep();
            updateProgress();
            
            if (currentStep === totalSteps) {
                generateResumePreview();
            }
        }
    }
}

function prevStep() {
    if (currentStep > 1) {
        currentStep--;
        updateStep();
        updateProgress();
    }
}

function updateStep() {
    formSteps.forEach(step => step.classList.remove('active'));
    steps.forEach(step => step.classList.remove('active', 'completed'));
    
    document.getElementById(`step-${currentStep}`).classList.add('active');
    document.querySelector(`[data-step="${currentStep}"]`).classList.add('active');
    
    for (let i = 1; i < currentStep; i++) {
        document.querySelector(`[data-step="${i}"]`).classList.add('completed');
    }
    
    prevBtn.disabled = currentStep === 1;
    nextBtn.textContent = currentStep === totalSteps ? 'Generate Resume' : 'Next';
    nextBtn.innerHTML = currentStep === totalSteps ? 
        '<i class="fas fa-magic"></i> Generate Resume' : 
        'Next <i class="fas fa-arrow-right"></i>';
}

function updateProgress() {
    const progress = (currentStep / totalSteps) * 100;
    progressFill.style.width = `${progress}%`;
}

function validateCurrentStep() {
    collectStepData();
    return true;
}

function collectStepData() {
    switch (currentStep) {
        case 1:
            resumeData.personalInfo = {
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                phone: document.getElementById('phone').value,
                location: document.getElementById('location').value,
                linkedin: document.getElementById('linkedin').value,
                website: document.getElementById('website').value
            };
            break;
        case 2:
            const experienceItem = {
                jobTitle: document.getElementById('jobTitle').value,
                company: document.getElementById('company').value,
                startDate: document.getElementById('startDate').value,
                endDate: document.getElementById('endDate').value,
                current: document.getElementById('currentJob').checked,
                description: document.getElementById('jobDescription').value
            };
            resumeData.experience.push(experienceItem);
            break;
        case 3:
            resumeData.targetRole = document.getElementById('targetRole').value;
            resumeData.industry = document.getElementById('industry').value;
            break;
        case 4:
            const educationItem = {
                degree: document.getElementById('degree').value,
                field: document.getElementById('field').value,
                institution: document.getElementById('institution').value,
                startDate: document.getElementById('eduStartDate').value,
                endDate: document.getElementById('eduEndDate').value,
                gpa: document.getElementById('gpa').value
            };
            resumeData.education.push(educationItem);
            break;
        case 5:
            resumeData.summary = document.getElementById('summary').value;
            break;
    }
}

async function generateAISummary() {
    if (!resumeData.personalInfo.name || !resumeData.targetRole || resumeData.skills.length === 0) {
        showToast('Please fill in your name, target role, and skills first', 'warning');
        return;
    }
    
    showLoading(true);
        
    try {
        const response = await fetch('/api/ai/generate-summary', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                name: resumeData.personalInfo.name,
                targetRole: resumeData.targetRole,
                skills: resumeData.skills,
                experience: resumeData.experience.map(exp => `${exp.jobTitle} at ${exp.company}`).join(', ')
            })
        });
        
        const data = await response.json();
        
        if (data.summary) {
            document.getElementById('summary').value = data.summary;
            showToast('Professional summary generated successfully!', 'success');
        } else {
            showToast('Failed to generate summary. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Error generating summary. Please try again.', 'error');
    }
    
    showLoading(false);
}

async function getAISuggestions() {
    if (!resumeData.personalInfo.name) {
        showToast('Please complete your resume first', 'warning');
        return;
    }
    
    showLoading(true);
        
    try {
        const response = await fetch('/api/ai/suggestions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                resumeData: resumeData
            })
        });
        
        const data = await response.json();
        displaySuggestions(data.suggestions);
        showToast('AI suggestions generated!', 'success');
    } catch (error) {
        console.error('Error:', error);
        showToast('Error getting suggestions. Please try again.', 'error');
    }
    
    showLoading(false);
}

async function improveJobDescription() {
    const jobTitle = document.getElementById('jobTitle').value;
    const company = document.getElementById('company').value;
    const description = document.getElementById('jobDescription').value;
    const industry = resumeData.industry || document.getElementById('industry').value;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('currentJob').checked ? 'present' : document.getElementById('endDate').value;
    
    if (!jobTitle || !description) {
        showToast('Please fill in job title and description first', 'warning');
        return;
    }
    
    showLoading(true);
    
    try {
        const response = await fetch('/api/ai/improve-experience', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                jobTitle: jobTitle,
                company: company || 'Company',
                jobDescription: description,
                industry: industry || 'General',
                startDate: startDate || '2022-01-01',
                endDate: endDate || 'present'
            })
        });
        
        const data = await response.json();
        
        if (data.improvedDescription) {
            document.getElementById('jobDescription').value = data.improvedDescription;
            showToast('Job description transformed into professional bullets!', 'success');
        } else {
            showToast('Failed to improve description. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Error improving description. Please try again.', 'error');
    }
    
    showLoading(false);
}

async function recommendSkills() {
    const targetRole = document.getElementById('targetRole').value;
    const industry = document.getElementById('industry').value;
    
    if (!targetRole) {
        showToast('Please enter your target role first', 'warning');
        return;
    }
    
    showLoading(true);
        
    try {
        const response = await fetch('/api/ai/recommend-skills', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                currentSkills: resumeData.skills,
                targetRole: targetRole,
                industry: industry || 'General'
            })
        });
        
        const data = await response.json();
        displaySkillRecommendations(data.recommendedSkills);
        showToast('New skill recommendations generated!', 'success');
    } catch (error) {
        console.error('Error:', error);
        showToast('Error getting recommendations. Please try again.', 'error');
    }
    
    showLoading(false);
}

function addExperience() {
    const container = document.getElementById('experience-container');
    const newExperience = document.createElement('div');
    newExperience.className = 'experience-item';
    newExperience.innerHTML = `
        <div class="form-group">
            <label for="jobTitle2">Job Title *</label>
            <input type="text" id="jobTitle2" required placeholder="Software Developer">
        </div>
        
        <div class="form-group">
            <label for="company2">Company *</label>
            <input type="text" id="company2" required placeholder="Tech Company Inc.">
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label for="startDate2">Start Date</label>
                <input type="month" id="startDate2">
            </div>
            <div class="form-group">
                <label for="endDate2">End Date</label>
                <input type="month" id="endDate2">
            </div>
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" id="currentJob2">
                    <span>Currently working here</span>
                </label>
            </div>
        </div>
        
        <div class="form-group">
            <label for="jobDescription2">Job Description</label>
            <textarea id="jobDescription2" rows="4" placeholder="Describe your role and key responsibilities..."></textarea>
            <button type="button" class="btn-ai" onclick="improveJobDescription2()">
                <i class="fas fa-magic"></i> Improve with AI
            </button>
        </div>
    `;
    container.appendChild(newExperience);
}

function addEducation() {
    const container = document.getElementById('education-container');
    const newEducation = document.createElement('div');
    newEducation.className = 'education-item';
    newEducation.innerHTML = `
        <div class="form-group">
            <label for="degree2">Degree *</label>
            <input type="text" id="degree2" required placeholder="Bachelor of Science">
        </div>
        
        <div class="form-group">
            <label for="field2">Field of Study</label>
            <input type="text" id="field2" placeholder="Computer Science">
        </div>
        
        <div class="form-group">
            <label for="institution2">Institution *</label>
            <input type="text" id="institution2" required placeholder="University Name">
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label for="eduStartDate2">Start Date</label>
                <input type="month" id="eduStartDate2">
            </div>
            <div class="form-group">
                <label for="eduEndDate2">End Date</label>
                <input type="month" id="eduEndDate2">
            </div>
            <div class="form-group">
                <label for="gpa2">GPA (Optional)</label>
                <input type="text" id="gpa2" placeholder="3.8">
            </div>
        </div>
    `;
    container.appendChild(newEducation);
}

function handleSkillInput(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        const skill = e.target.value.trim();
        if (skill && !resumeData.skills.includes(skill)) {
            addSkill(skill);
            e.target.value = '';
        }
    }
}

function addSkill(skill) {
    resumeData.skills.push(skill);
    const skillsList = document.getElementById('skills-list');
    const skillTag = document.createElement('div');
    skillTag.className = 'skill-tag';
    skillTag.innerHTML = `
        ${skill}
        <button type="button" class="remove-skill" onclick="removeSkill('${skill}')">
            <i class="fas fa-times"></i>
        </button>
    `;
    skillsList.appendChild(skillTag);
}

function removeSkill(skill) {
    resumeData.skills = resumeData.skills.filter(s => s !== skill);
    const skillTags = document.querySelectorAll('.skill-tag');
    skillTags.forEach(tag => {
        if (tag.textContent.includes(skill)) {
            tag.remove();
        }
    });
}

function handleCurrentJob() {
    const endDate = document.getElementById('endDate');
    const currentJob = document.getElementById('currentJob');
    
    if (currentJob.checked) {
        endDate.disabled = true;
        endDate.value = '';
    } else {
        endDate.disabled = false;
    }
}

function handlePhotoUpload(event) {
    const file = event.target.files[0];
    if (file) {
        if (!file.type.startsWith('image/')) {
            showToast('Please select a valid image file', 'error');
            return;
        }
        
        if (file.size > 5 * 1024 * 1024) {
            showToast('Image size should be less than 5MB', 'error');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            resumeData.photo = e.target.result;
            displayPhotoPreview(e.target.result);
            showToast('Photo uploaded successfully!', 'success');
        };
        reader.readAsDataURL(file);
    }
}

function displayPhotoPreview(imageSrc) {
    const preview = document.getElementById('photo-preview');
    const previewImg = document.getElementById('photo-preview-img');
    
    previewImg.src = imageSrc;
    preview.style.display = 'block';
}

function removePhoto() {
    resumeData.photo = null;
    document.getElementById('photo').value = '';
    document.getElementById('photo-preview').style.display = 'none';
    showToast('Photo removed', 'info');
}

function displaySuggestions(suggestions) {
    const suggestionsList = document.getElementById('suggestions-list');
    suggestionsList.innerHTML = '';
    
    suggestions.forEach(suggestion => {
        const suggestionItem = document.createElement('div');
        suggestionItem.className = `suggestion-item ${suggestion.priority.toLowerCase()}`;
        suggestionItem.innerHTML = `
            <div class="suggestion-category">${suggestion.category}</div>
            <div class="suggestion-text">${suggestion.suggestion}</div>
            <div class="suggestion-reason">${suggestion.reason}</div>
        `;
        suggestionsList.appendChild(suggestionItem);
    });
}

function displaySkillRecommendations(skills) {
    const skillsList = document.getElementById('skills-list');
    
    skills.forEach(skill => {
        if (!resumeData.skills.includes(skill)) {
            const skillTag = document.createElement('div');
            skillTag.className = 'skill-tag';
            skillTag.style.background = 'linear-gradient(135deg, #10b981, #059669)';
            skillTag.innerHTML = `
                ${skill}
                <button type="button" class="remove-skill" onclick="removeSkill('${skill}')">
                    <i class="fas fa-times"></i>
                </button>
            `;
            skillsList.appendChild(skillTag);
            resumeData.skills.push(skill);
        }
    });
}

function generateResumePreview() {
    const preview = document.getElementById('resume-preview');
    const data = resumeData;
    
    preview.innerHTML = `
        <div class="resume-document">
            <div class="resume-header">
                <div class="header-content">
                    <div class="header-main">
                        ${data.photo ? `<div class="photo-container"><img src="${data.photo}" alt="Profile Photo" class="profile-photo"></div>` : ''}
                        <div class="name-info">
                            <h1 class="name">${data.personalInfo.name || 'Your Name'}</h1>
                            <div class="contact-info">
                                ${data.personalInfo.email ? `<div class="contact-item"><i class="fas fa-envelope"></i> ${data.personalInfo.email}</div>` : ''}
                                ${data.personalInfo.phone ? `<div class="contact-item"><i class="fas fa-phone"></i> ${data.personalInfo.phone}</div>` : ''}
                                ${data.personalInfo.location ? `<div class="contact-item"><i class="fas fa-map-marker-alt"></i> ${data.personalInfo.location}</div>` : ''}
                            </div>
                            <div class="links">
                                ${data.personalInfo.linkedin ? `<a href="${data.personalInfo.linkedin}" target="_blank" class="link" rel="noopener noreferrer"><i class="fab fa-linkedin"></i> LinkedIn</a>` : ''}
                                ${data.personalInfo.website ? `<a href="${data.personalInfo.website}" target="_blank" class="link" rel="noopener noreferrer"><i class="fas fa-globe"></i> Portfolio</a>` : ''}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            ${data.summary ? `
                <div class="resume-section">
                <div class="section-header">
                    <h2><i class="fas fa-user"></i> Professional Summary</h2>
                </div>
                <div class="section-content">
                    <p class="summary-text">${data.summary}</p>
                </div>
                </div>
            ` : ''}
            
            ${data.skills.length > 0 ? `
                <div class="resume-section">
                <div class="section-header">
                    <h2><i class="fas fa-cogs"></i> Technical Skills</h2>
                </div>
                <div class="section-content">
                    <div class="skills-grid">
                        ${data.skills.map(skill => `<span class="skill-item">${skill}</span>`).join('')}
                    </div>
                </div>
                </div>
            ` : ''}
            
            ${data.experience.length > 0 ? `
                <div class="resume-section">
                <div class="section-header">
                    <h2><i class="fas fa-briefcase"></i> Professional Experience</h2>
                </div>
                <div class="section-content">
                    ${data.experience.map(exp => `
                        <div class="experience-item">
                            <div class="job-header">
                                <div class="job-title-company">
                                    <h3 class="job-title">${exp.jobTitle}</h3>
                                    <h4 class="company-name">${exp.company}</h4>
                                </div>
                                <div class="job-dates">
                                    <span class="date-range">${formatDate(exp.startDate)} - ${exp.current ? 'Present' : formatDate(exp.endDate)}</span>
                                </div>
                            </div>
                            ${exp.description ? `<div class="job-description"><p>${exp.description}</p></div>` : ''}
                        </div>
                    `).join('')}
                </div>
                </div>
            ` : ''}
            
            ${data.education.length > 0 ? `
                <div class="resume-section">
                <div class="section-header">
                    <h2><i class="fas fa-graduation-cap"></i> Education</h2>
                </div>
                <div class="section-content">
                    ${data.education.map(edu => `
                        <div class="education-item">
                            <div class="edu-header">
                                <div class="degree-info">
                                    <h3 class="degree">${edu.degree}${edu.field ? ` in ${edu.field}` : ''}</h3>
                                    <h4 class="institution">${edu.institution}</h4>
                                </div>
                                <div class="edu-dates">
                                    <span class="date-range">${formatDate(edu.startDate)} - ${formatDate(edu.endDate)}</span>
                                    ${edu.gpa ? `<span class="gpa">GPA: ${edu.gpa}</span>` : ''}
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
                </div>
            ` : ''}
        </div>
    `;
}

function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString + '-01');
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
}

function showLoading(show) {
    if (show) {
        loadingOverlay.classList.add('active');
        } else {
        loadingOverlay.classList.remove('active');
    }
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icon = type === 'success' ? 'check-circle' : 
                 type === 'error' ? 'exclamation-circle' : 
                 type === 'warning' ? 'exclamation-triangle' : 'info-circle';
    
    toast.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
    `;
    
    toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

function downloadResume() {
    const resumeElement = document.getElementById('resume-preview');
    const name = resumeData.personalInfo.name || 'Resume';
    
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
            <head>
                <title>${name} - Resume</title>
                <style>
                    * { margin: 0; padding: 0; box-sizing: border-box; }
                    body { 
                        font-family: 'Inter', Arial, sans-serif; 
                        line-height: 1.6;
                        color: #1a1a1a;
                        background: white;
                    }
                    .resume-document {
                        max-width: 100%;
                        background: white;
                    }
                    .resume-header {
                        background: linear-gradient(135deg, #2563eb, #1d4ed8);
                        color: white;
                        padding: 2.5rem 2rem;
                        text-align: center;
                    }
                    .header-main {
                        display: flex;
                        align-items: center;
                        gap: 2rem;
                        text-align: left;
                    }
                    .photo-container {
                        flex-shrink: 0;
                    }
                    .profile-photo {
                        width: 120px;
                        height: 120px;
                        object-fit: cover;
                        border-radius: 50%;
                        border: 4px solid rgba(255, 255, 255, 0.3);
                        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
                    }
                    .name-info {
                        flex: 1;
                    }
                    .header-content .name {
                        font-size: 2.5rem;
                        font-weight: 700;
                        margin: 0 0 1rem 0;
                        letter-spacing: -0.02em;
                    }
                    .contact-info {
                        display: flex;
                        justify-content: center;
                        gap: 2rem;
                        margin-bottom: 1rem;
                        flex-wrap: wrap;
                    }
                    .contact-item {
                        display: flex;
                        align-items: center;
                        gap: 0.5rem;
                        font-size: 0.95rem;
                        opacity: 0.9;
                    }
                    .links {
                        display: flex;
                        justify-content: center;
                        gap: 1.5rem;
                        flex-wrap: wrap;
                    }
                    .link {
                        color: white;
                        text-decoration: none;
                        display: flex;
                        align-items: center;
                        gap: 0.5rem;
                        padding: 0.5rem 1rem;
                        background: rgba(255, 255, 255, 0.1);
                        border-radius: 0.375rem;
                        font-size: 0.9rem;
                    }
                    .resume-section {
                        padding: 2rem;
                        border-bottom: 1px solid #f0f0f0;
                    }
                    .resume-section:last-child {
                        border-bottom: none;
                    }
                    .section-header {
                        margin-bottom: 1.5rem;
                    }
                    .section-header h2 {
                        color: #2563eb;
                        font-size: 1.4rem;
                        font-weight: 600;
                        margin: 0;
                        display: flex;
                        align-items: center;
                        gap: 0.75rem;
                        padding-bottom: 0.5rem;
                        border-bottom: 2px solid #2563eb;
                    }
                    .summary-text {
                        font-size: 1rem;
                        line-height: 1.7;
                        color: #444;
                        margin: 0;
                    }
                    .skills-grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                        gap: 0.75rem;
                    }
                    .skill-item {
                        background: linear-gradient(135deg, #f8fafc, #e2e8f0);
                        border: 1px solid #e2e8f0;
                        padding: 0.75rem 1rem;
                        border-radius: 0.375rem;
                        font-size: 0.9rem;
                        font-weight: 500;
                        color: #374151;
                        text-align: center;
                    }
                    .experience-item {
                        margin-bottom: 2rem;
                        padding-bottom: 1.5rem;
                        border-bottom: 1px solid #f0f0f0;
                    }
                    .experience-item:last-child {
                        border-bottom: none;
                        margin-bottom: 0;
                        padding-bottom: 0;
                    }
                    .job-header {
                        display: flex;
                        justify-content: space-between;
                        align-items: flex-start;
                        margin-bottom: 0.75rem;
                        flex-wrap: wrap;
                        gap: 1rem;
                    }
                    .job-title-company {
                        flex: 1;
                        min-width: 200px;
                    }
                    .job-title {
                        font-size: 1.2rem;
                        font-weight: 600;
                        color: #1a1a1a;
                        margin: 0 0 0.25rem 0;
                    }
                    .company-name {
                        font-size: 1rem;
                        font-weight: 500;
                        color: #2563eb;
                        margin: 0;
                    }
                    .job-dates {
                        text-align: right;
                        min-width: 120px;
                    }
                    .date-range {
                        background: #f8fafc;
                        color: #64748b;
                        padding: 0.25rem 0.75rem;
                        border-radius: 0.375rem;
                        font-size: 0.85rem;
                        font-weight: 500;
                        border: 1px solid #e2e8f0;
                    }
                    .job-description {
                        margin-top: 0.75rem;
                    }
                    .job-description p {
                        margin: 0;
                        color: #444;
                        line-height: 1.6;
                        white-space: pre-line;
                    }
                    .education-item {
                        margin-bottom: 1.5rem;
                        padding-bottom: 1rem;
                        border-bottom: 1px solid #f0f0f0;
                    }
                    .education-item:last-child {
                        border-bottom: none;
                        margin-bottom: 0;
                        padding-bottom: 0;
                    }
                    .edu-header {
                        display: flex;
                        justify-content: space-between;
                        align-items: flex-start;
                        flex-wrap: wrap;
                        gap: 1rem;
                    }
                    .degree-info {
                        flex: 1;
                        min-width: 200px;
                    }
                    .degree {
                        font-size: 1.1rem;
                        font-weight: 600;
                        color: #1a1a1a;
                        margin: 0 0 0.25rem 0;
                    }
                    .institution {
                        font-size: 1rem;
                        font-weight: 500;
                        color: #2563eb;
                        margin: 0;
                    }
                    .edu-dates {
                        text-align: right;
                        min-width: 120px;
                        display: flex;
                        flex-direction: column;
                        gap: 0.25rem;
                    }
                    .gpa {
                        background: #fef3c7;
                        color: #92400e;
                        padding: 0.25rem 0.75rem;
                        border-radius: 0.375rem;
                        font-size: 0.85rem;
                        font-weight: 500;
                        border: 1px solid #fde68a;
                    }
                    @media print { 
                        body { margin: 0; }
                        .resume-document { box-shadow: none; }
                        .skill-item { 
                            background: #f8fafc !important; 
                            color: #374151 !important;
                        }
                    }
                </style>
            </head>
            <body>
                ${resumeElement.innerHTML}
            </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
    
    showToast('Resume downloaded successfully!', 'success');
}

function saveResume() {
    const resumeJSON = JSON.stringify(resumeData, null, 2);
    const blob = new Blob([resumeJSON], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `${resumeData.personalInfo.name || 'resume'}-data.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showToast('Resume data saved successfully!', 'success');
}

window.improveJobDescription2 = function() {
    showToast('AI improvement feature for additional experiences coming soon!', 'info');
};