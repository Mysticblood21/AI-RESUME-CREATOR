const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

let genAI, model;

if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'your_gemini_api_key_here') {
    try {
        const { GoogleGenerativeAI } = require('@google/generative-ai');
        genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        model = genAI.getGenerativeModel({ model: "gemini-pro" });
        console.log('✅ Gemini AI initialized successfully');
    } catch (error) {
        console.log('❌ Failed to initialize Gemini AI:', error.message);
    }
} else {
    console.log('⚠️ Gemini API key not found. AI features will use fallback responses.');
}

function calculateDuration(startDate, endDate) {
    const start = new Date(startDate);
    const end = endDate && endDate.toLowerCase() !== 'present' ? new Date(endDate) : new Date();
    const months = (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
    return Math.max(1, months);
}

function formatDuration(months) {
    const years = Math.floor(months / 12);
    const remainingMonths = months % 12;
    
    if (years === 0) {
        return `${months} month${months !== 1 ? 's' : ''}`;
    } else if (remainingMonths === 0) {
        return `${years} year${years !== 1 ? 's' : ''}`;
    } else {
        return `${years} year${years !== 1 ? 's' : ''} and ${remainingMonths} month${remainingMonths !== 1 ? 's' : ''}`;
    }
}

app.post('/api/ai/generate-summary', async (req, res) => {
  try {
    const { experience, skills, targetRole, name } = req.body;
    
    if (!model) {
      const fallbackSummary = generateFallbackSummary(name, targetRole, skills, experience);
      return res.json({ summary: fallbackSummary });
    }
    
    let totalMonths = 0;
    let experienceContext = '';
    
    if (experience && Array.isArray(experience)) {
      totalMonths = experience.reduce((sum, job) => {
        if (job.startDate) {
          return sum + calculateDuration(job.startDate, job.endDate);
        }
        return sum;
      }, 0);
      
      experienceContext = experience.map((job, idx) => {
        const duration = calculateDuration(job.startDate, job.endDate);
        return `${idx + 1}. ${job.title} at ${job.company} (${formatDuration(duration)})`;
      }).join('\n');
    }
    
    const totalYears = Math.floor(totalMonths / 12);
    const experienceLevel = totalYears < 2 ? 'early-career' : totalYears < 5 ? 'mid-level' : 'senior';
    
    const prompt = `Create a compelling professional summary for a resume based on ACTUAL experience.

Name: ${name}
Target Role: ${targetRole}
Experience Level: ${experienceLevel} (${totalYears}+ years total)
Top Skills: ${skills.slice(0, 5).join(', ')}

ACTUAL WORK HISTORY:
${experienceContext}

CRITICAL INSTRUCTIONS:
- Write a 3-4 sentence summary that reflects their ACTUAL ${totalYears}+ years of experience
- Reference their specific experience level (don't say "5+ years" if they only have 2 years)
- Mention skills they ACTUALLY have from the list provided
- Use strong action words but keep it realistic to their career stage
- For early-career: Focus on growth, learning, and recent achievements
- For mid-level: Emphasize proven track record and specialized skills
- For senior: Highlight leadership, strategy, and significant impact
- NO generic phrases like "hardworking" or "team player"
- Make it specific to their actual background

Return ONLY the summary text, nothing else.`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const summary = response.text();

    res.json({ summary: summary.trim() });
  } catch (error) {
    console.error('AI Summary Error:', error);
    const { experience, skills, targetRole, name } = req.body;
    const fallbackSummary = generateFallbackSummary(name, targetRole, skills, experience);
    res.json({ summary: fallbackSummary });
  }
});

app.post('/api/ai/suggestions', async (req, res) => {
  try {
    const { resumeData } = req.body;
    
    if (!model) {
      const fallbackSuggestions = generateFallbackSuggestions(resumeData);
      return res.json({ suggestions: fallbackSuggestions });
    }
    
    let experienceAnalysis = '';
    if (resumeData.experience && Array.isArray(resumeData.experience)) {
      experienceAnalysis = resumeData.experience.map((job, idx) => {
        const duration = calculateDuration(job.startDate, job.endDate);
        return `Job ${idx + 1}: ${job.title} at ${job.company} - ${formatDuration(duration)}`;
      }).join('\n');
    }
    
    const prompt = `Analyze this resume and provide SPECIFIC, ACTIONABLE suggestions based on their ACTUAL experience:

RESUME DATA:
${JSON.stringify(resumeData, null, 2)}

EXPERIENCE TIMELINE:
${experienceAnalysis}

ANALYSIS INSTRUCTIONS:
1. Look at their job durations - are they too short (job hopping) or too long (stagnation)?
2. Check if descriptions match their experience level
3. Identify missing quantifiable achievements
4. Find skills gaps for their target role
5. Check for formatting/ATS issues

Provide suggestions in these categories:
- Content improvements (better wording for THEIR actual descriptions)
- Skills recommendations (missing skills for THEIR roles)
- Experience enhancements (how to improve THEIR job descriptions)
- Duration concerns (if any jobs are too short/long)
- ATS optimization (keywords missing from THEIR industry)

Format as JSON:
{
  "suggestions": [
    {
      "category": "Content",
      "suggestion": "specific suggestion based on their actual content",
      "priority": "High/Medium/Low",
      "reason": "why this helps based on their situation"
    }
  ]
}

Be SPECIFIC to their actual resume, not generic advice.`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const suggestionsText = response.text();

    try {
      const jsonMatch = suggestionsText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const suggestions = JSON.parse(jsonMatch[0]);
        res.json(suggestions);
      } else {
        throw new Error('No JSON found');
      }
    } catch (parseError) {
      const fallbackSuggestions = generateFallbackSuggestions(resumeData);
      res.json({ suggestions: fallbackSuggestions });
    }
  } catch (error) {
    console.error('AI Suggestions Error:', error);
    const { resumeData } = req.body;
    const fallbackSuggestions = generateFallbackSuggestions(resumeData);
    res.json({ suggestions: fallbackSuggestions });
  }
});

app.post('/api/ai/improve-experience', async (req, res) => {
  try {
    const { jobDescription, jobTitle, company, industry, startDate, endDate } = req.body;
    
    if (!model) {
      const fallbackDescription = improveFallbackDescription(jobDescription);
      return res.json({ improvedDescription: fallbackDescription });
    }
    
    const defaultStart = startDate || '2022-01-01';
    const defaultEnd = endDate || 'present';
    const duration = calculateDuration(defaultStart, defaultEnd);
    const durationText = formatDuration(duration);
    
    const prompt = `You are a professional resume writer. I will give you brief keywords about a job. You must write 3-4 COMPLETELY NEW bullet points that describe what someone in this role actually does.

RULES YOU MUST FOLLOW:
1. DO NOT use the user's exact words anywhere in your response
2. Write what a ${jobTitle} DOES, not what they ARE
3. Start with action verbs: Developed, Built, Led, Managed, Created, Implemented, Designed, Engineered, Architected
4. Include specific details: numbers, technologies, outcomes
5. Write 3-4 bullets, each 20-30 words long
6. Return ONLY the bullets with • character, nothing else

JOB DETAILS:
Position: ${jobTitle} at ${company}
Industry: ${industry || 'General'}
Duration: ${durationText}

USER'S KEYWORDS: "${jobDescription}"

EXAMPLE TRANSFORMATIONS:

User input: "python expert"
WRONG: • Python expert with strong skills
RIGHT: 
• Developed microservices using Python, Flask, and PostgreSQL serving 100K+ requests daily
• Built automated data pipelines with Pandas processing 50GB datasets, reducing manual work by 80%
• Implemented REST APIs using FastAPI that improved system response time by 40%

User input: "team management"
WRONG: • Good at team management
RIGHT:
• Led cross-functional team of 8 engineers delivering 15+ features per quarter
• Mentored 4 junior developers through code reviews and 1-on-1s, improving code quality by 35%
• Coordinated sprint planning and retrospectives using Agile methodology

User input: "marketing campaigns"
WRONG: • Ran marketing campaigns
RIGHT:
• Launched 12+ digital marketing campaigns generating $500K revenue and 50K new leads
• Optimized Google Ads spending reducing cost-per-acquisition by 30% while maintaining conversion rates
• A/B tested email campaigns increasing open rates from 18% to 34%

NOW WRITE 3-4 BULLETS FOR: ${jobTitle}
Use the keywords "${jobDescription}" as inspiration but write COMPLETELY NEW descriptions.
Return ONLY the bullets with •, no other text.`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    let improvedDescription = response.text().trim();
    
    const lines = improvedDescription.split('\n').filter(line => line.trim() !== '');
    const bulletPoints = lines.filter(line => {
      const trimmed = line.trim();
      return trimmed.startsWith('•') || trimmed.startsWith('-') || trimmed.startsWith('*');
    }).map(line => {
      return line.trim().replace(/^[-*]\s*/, '• ');
    });
    
    if (bulletPoints.length < 3) {
      const baseBullets = [
        `• Developed and implemented solutions for ${jobTitle} role, delivering measurable results and improving operational efficiency`,
        `• Collaborated with cross-functional teams to execute projects and achieve organizational goals`,
        `• Applied technical expertise and problem-solving skills to drive continuous improvement initiatives`
      ];
      return res.json({ improvedDescription: baseBullets.join('\n') });
    }

    res.json({ improvedDescription: bulletPoints.join('\n') });
  } catch (error) {
    console.error('AI Experience Error:', error);
    const { jobDescription } = req.body;
    const fallbackDescription = improveFallbackDescription(jobDescription);
    res.json({ improvedDescription: fallbackDescription });
  }
});

app.post('/api/ai/recommend-skills', async (req, res) => {
  try {
    const { currentSkills, targetRole, industry, experience } = req.body;
    
    if (!model) {
      const fallbackSkills = generateFallbackSkills(targetRole, industry);
      const filteredSkills = fallbackSkills.filter(skill => 
        !currentSkills.some(current => current.toLowerCase().includes(skill.toLowerCase()))
      );
      return res.json({ recommendedSkills: filteredSkills.slice(0, 8) });
    }
    
    let totalMonths = 0;
    let roleContext = '';
    if (experience && Array.isArray(experience)) {
      totalMonths = experience.reduce((sum, job) => {
        if (job.startDate) {
          return sum + calculateDuration(job.startDate, job.endDate);
        }
        return sum;
      }, 0);
      
      roleContext = experience.map(job => `${job.title} (${formatDuration(calculateDuration(job.startDate, job.endDate))})`).join(', ');
    }
    
    const totalYears = Math.floor(totalMonths / 12);
    const experienceLevel = totalYears < 2 ? 'Junior' : totalYears < 5 ? 'Mid-Level' : 'Senior';
    
    const prompt = `Recommend skills for someone with ACTUAL experience in these roles.

TARGET ROLE: ${targetRole}
INDUSTRY: ${industry}
EXPERIENCE LEVEL: ${experienceLevel} (${totalYears}+ years)
ACTUAL ROLES HELD: ${roleContext}

CURRENT SKILLS:
${currentSkills.join(', ')}

INSTRUCTIONS:
1. Recommend 8-10 skills that make sense for their experience level:
   - Junior: Foundational skills, common tools, basics they should learn next
   - Mid-Level: Advanced technical skills, specialized tools, soft skills for growth
   - Senior: Leadership skills, strategic tools, architecture, mentoring abilities
2. Base recommendations on their ACTUAL career path (${roleContext})
3. Exclude skills they already have
4. Focus on what employers ACTUALLY look for at their level
5. Include mix of technical and soft skills appropriate for ${totalYears}+ years experience
6. Make sure skills are relevant to "${targetRole}" specifically

Return as a simple list, one skill per line, no numbering or bullets. Be realistic about what they should learn next based on where they actually are in their career.`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const skillsText = response.text();
    
    const recommendedSkills = skillsText
      .split('\n')
      .map(skill => skill.replace(/^\d+\.\s*/, '').replace(/^[-*•]\s*/, '').trim())
      .filter(skill => skill.length > 0 && !currentSkills.some(current => 
        current.toLowerCase().includes(skill.toLowerCase())
      ))
      .slice(0, 10);

    res.json({ recommendedSkills });
  } catch (error) {
    console.error('AI Skills Error:', error);
    const { currentSkills, targetRole, industry } = req.body;
    const fallbackSkills = generateFallbackSkills(targetRole, industry);
    const filteredSkills = fallbackSkills.filter(skill => 
      !currentSkills.some(current => current.toLowerCase().includes(skill.toLowerCase()))
    );
    res.json({ recommendedSkills: filteredSkills.slice(0, 8) });
  }
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

function generateFallbackSummary(name, targetRole, skills, experience) {
  const topSkills = skills.slice(0, 3).join(', ');
  return `Experienced ${targetRole} with expertise in ${topSkills}. Proven track record of delivering high-quality results and collaborating effectively with cross-functional teams. Strong analytical and problem-solving skills with a passion for continuous learning and innovation.`;
}

function generateFallbackSuggestions(resumeData) {
  const suggestions = [];
  
  if (!resumeData.personalInfo?.name) {
    suggestions.push({
      category: "Personal Information",
      suggestion: "Add your full name and contact information",
      priority: "High",
      reason: "Essential for employer identification"
    });
  }
  
  if (!resumeData.experience || resumeData.experience.length === 0) {
    suggestions.push({
      category: "Experience",
      suggestion: "Add your work experience with detailed job descriptions",
      priority: "High",
      reason: "Work experience is crucial for most positions"
    });
  }
  
  if (!resumeData.skills || resumeData.skills.length < 5) {
    suggestions.push({
      category: "Skills",
      suggestion: "Add more relevant skills to strengthen your profile",
      priority: "Medium",
      reason: "More skills make you more competitive"
    });
  }
  
  if (!resumeData.summary) {
    suggestions.push({
      category: "Summary",
      suggestion: "Add a professional summary highlighting your key strengths",
      priority: "Medium",
      reason: "Helps recruiters quickly understand your value"
    });
  }
  
  suggestions.push({
    category: "General",
    suggestion: "Use action verbs in your job descriptions (e.g., 'Developed', 'Implemented', 'Led')",
    priority: "Medium",
    reason: "Action verbs make your experience more impactful"
  });
  
  return suggestions;
}

function generateFallbackSkills(targetRole, industry) {
  const skillSets = {
    'software developer': ['JavaScript', 'Python', 'React', 'Node.js', 'Git', 'SQL', 'Agile', 'Problem Solving'],
    'marketing': ['Digital Marketing', 'SEO', 'Social Media', 'Analytics', 'Content Creation', 'Campaign Management'],
    'finance': ['Financial Analysis', 'Excel', 'QuickBooks', 'Budgeting', 'Risk Management', 'Data Analysis'],
    'design': ['Adobe Creative Suite', 'Figma', 'UI/UX Design', 'Typography', 'Color Theory', 'Prototyping'],
    'sales': ['Customer Relations', 'Negotiation', 'CRM Software', 'Lead Generation', 'Communication']
  };
  
  const roleKey = targetRole.toLowerCase();
  for (const [key, skills] of Object.entries(skillSets)) {
    if (roleKey.includes(key)) return skills;
  }
  return skillSets['software developer'];
}

function improveFallbackDescription(description) {
  if (!description || description.trim() === '') {
    return `• Led key initiatives that drove measurable results and improved operational efficiency
• Collaborated with cross-functional teams to deliver high-impact projects
• Implemented process improvements that enhanced team productivity`;
  }
  
  const improved = description.trim().replace(/^[•\-\*]\s*/, '');
  return `• ${improved.charAt(0).toUpperCase() + improved.slice(1)}${improved.endsWith('.') ? '' : '.'}
• Collaborated with team members to deliver quality results
• Contributed to projects and gained valuable experience`;
}

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📝 AI Resume Builder is ready!`);
});